d = {i: i + 1 for i in range(11)}  
print(d)
