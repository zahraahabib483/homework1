L = ['Network', 'Bio', 'Programming', 'Physics', 'Music']

for i in L:
    if i.startswith('B'):
        print(i)
